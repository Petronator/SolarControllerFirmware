#ifndef analog_h
#define analog_h

#define AN_num_Vbatt					0
#define AN_num_Vsolar					1
#define AN_num_Vload					2
#define AN_num_Isolar					3
#define AN_num_Iload					4
#define AN_num_Temp						5
#define AN_num_Intref					6

#define VREFINT_CAL_ADDR    0x1FFFF7BA
#define FULL_SCALE					0xFFF

#define RSENSE_MOHM					3
#define ISENSE_GAIN					100
#define VOLTTOAMP_MOHM			(RSENSE_MOHM * ISENSE_GAIN)


#endif